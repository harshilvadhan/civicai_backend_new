from fastapi import APIRouter, UploadFile, File, HTTPException
from services import db_service
import uuid

router = APIRouter()


# ─── POST /upload/image ───────────────────────────────────────────────────────
# Person 1 calls this BEFORE submitting the complaint.
# Returns a public URL → Person 1 includes it in the final POST /complaints.

@router.post("/image")
async def upload_image(file: UploadFile = File(...)):
    allowed = {"image/jpeg", "image/png", "image/webp", "image/gif"}
    if file.content_type not in allowed:
        raise HTTPException(status_code=400, detail="Only image files allowed.")

    contents = await file.read()
    if len(contents) > 5 * 1024 * 1024:   # 5 MB limit
        raise HTTPException(status_code=400, detail="Image must be under 5 MB.")

    ext      = file.filename.split(".")[-1]
    filename = f"{uuid.uuid4()}.{ext}"

    url = db_service.upload_image(filename, contents, file.content_type)
    return {"image_url": url}
