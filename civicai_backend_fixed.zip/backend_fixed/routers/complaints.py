from fastapi import APIRouter, HTTPException
from models import ComplaintCreate, ComplaintOut, TrackResponse, StatusEnum
from services import db_service
from datetime import datetime
import uuid

router = APIRouter()


def generate_ticket_id() -> str:
    """Human-readable ticket ID e.g. CMP-7A3F"""
    short = str(uuid.uuid4()).upper()[:4]
    return f"CMP-{short}"


# ─── POST /complaints ─────────────────────────────────────────────────────────
# Called by Person 1 (Frontend) after citizen confirms the AI draft.
# Person 3's AI fields arrive pre-filled — no parsing needed on our side.

@router.post("/", response_model=ComplaintOut, status_code=201)
def submit_complaint(payload: ComplaintCreate):
    ticket_id = generate_ticket_id()

    row = {
        "ticket_id":            ticket_id,
        "raw_input":            payload.raw_input,
        "location":             payload.location,
        "image_url":            payload.image_url,
        "category":             payload.category.value,
        "urgency":              payload.urgency.value,
        "formal_complaint":     payload.formal_complaint,
        "department":           payload.suggested_department,
        "reasoning":            payload.reasoning,
        "status":               StatusEnum.pending.value,
        "created_at":           datetime.utcnow().isoformat(),
    }

    saved = db_service.insert_complaint(row)

    # Seed the first timeline entry
    db_service.insert_status_update(
        saved["id"], StatusEnum.pending.value, "Complaint submitted by citizen."
    )

    return {
        "id":         saved["id"],
        "ticket_id":  saved["ticket_id"],
        "status":     saved["status"],
        "category":   saved["category"],
        "urgency":    saved["urgency"],
        "department": saved["department"],
        "created_at": saved["created_at"],
    }


# ─── GET /complaints/{ticket_id} ──────────────────────────────────────────────
# Citizen tracking — paste ticket ID, see full timeline.

@router.get("/{ticket_id}", response_model=TrackResponse)
def track_complaint(ticket_id: str):
    complaint = db_service.get_complaint_by_ticket(ticket_id)
    if not complaint:
        raise HTTPException(status_code=404, detail="Ticket not found.")

    timeline = db_service.get_status_timeline(complaint["id"])

    return {
        **complaint,
        "department":       complaint["department"],
        "formal_complaint": complaint["formal_complaint"],
        "timeline":         timeline,
    }
