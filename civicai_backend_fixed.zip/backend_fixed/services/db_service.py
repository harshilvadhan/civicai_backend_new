from supabase import create_client, Client
from config import settings

# One shared client for the whole app
supabase: Client = create_client(settings.SUPABASE_URL, settings.SUPABASE_KEY)


# ─── Complaints ───────────────────────────────────────────────────────────────

def insert_complaint(data: dict) -> dict:
    res = supabase.table("complaints").insert(data).execute()
    return res.data[0]

def get_complaint_by_ticket(ticket_id: str) -> dict | None:
    res = supabase.table("complaints").select("*").eq("ticket_id", ticket_id).execute()
    return res.data[0] if res.data else None

def get_complaint_by_id(complaint_id: str) -> dict | None:
    res = supabase.table("complaints").select("*").eq("id", complaint_id).execute()
    return res.data[0] if res.data else None

def update_complaint_status(complaint_id: str, status: str) -> dict:
    res = (supabase.table("complaints")
           .update({"status": status})
           .eq("id", complaint_id)
           .execute())
    return res.data[0]

def get_all_complaints(urgency: str = None, category: str = None) -> list:
    query = supabase.table("complaints").select("*").order("created_at", desc=True)
    if urgency:
        query = query.eq("urgency", urgency)
    if category:
        query = query.eq("category", category)
    return query.execute().data


# ─── Status Updates (timeline) ────────────────────────────────────────────────

def insert_status_update(complaint_id: str, status: str, note: str = "") -> dict:
    data = {"complaint_id": complaint_id, "status": status, "note": note}
    res = supabase.table("status_updates").insert(data).execute()
    return res.data[0]

def get_status_timeline(complaint_id: str) -> list:
    res = (supabase.table("status_updates")
           .select("*")
           .eq("complaint_id", complaint_id)
           .order("updated_at", desc=False)
           .execute())
    return res.data


# ─── Image Upload ─────────────────────────────────────────────────────────────

def upload_image(filename: str, file_bytes: bytes, content_type: str) -> str:
    """Upload image to Supabase Storage, return public URL."""
    bucket = settings.SUPABASE_BUCKET
    path   = f"complaints/{filename}"
    supabase.storage.from_(bucket).upload(
        path, file_bytes, {"content-type": content_type, "upsert": "true"}
    )
    public_url = supabase.storage.from_(bucket).get_public_url(path)
    return public_url
